from django.contrib import admin

from .models import ExerciseGoal
# Register your models here.

admin.site.register(ExerciseGoal)
