from django.apps import AppConfig


class ExerciseGoalsConfig(AppConfig):
    name = 'exercise_goals'
