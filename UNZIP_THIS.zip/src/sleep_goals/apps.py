from django.apps import AppConfig


class SleepGoalsConfig(AppConfig):
    name = 'sleep_goals'
