from django.contrib import admin

from .models import SleepGoal
# Register your models here.

admin.site.register(SleepGoal)