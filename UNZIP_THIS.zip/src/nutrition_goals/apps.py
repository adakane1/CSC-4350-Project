from django.apps import AppConfig


class NutritionGoalsConfig(AppConfig):
    name = 'nutrition_goals'
