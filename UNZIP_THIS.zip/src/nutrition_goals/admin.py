from django.contrib import admin

from .models import NutritionGoal
# Register your models here.

admin.site.register(NutritionGoal)
