from django.shortcuts import render

from .forms import ProfileForm

from .models import Profile

from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
# Create your views here.

def profile_fill_view(request):
    form = ProfileForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('dash')
    context = {
        'form': form
    }
    return render(request, "profiles/profile_fill.html", context)

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            # print(request.user)
            return redirect('dash')
    else:
        form = UserCreationForm()
    return render(request, 'profiles/signup.html', {'form': form})

# def user_detail_view(request):
#     obj = Profile.objects.get(id=1)

#     context = {
#         'object': obj
#     }
#     return render(request, "profiles/detail.html", context)