from django.apps import AppConfig


class WeightGoalConfig(AppConfig):
    name = 'weight_goal'
