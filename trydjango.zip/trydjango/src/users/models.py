from django.db import models

# Create your models here.
class Users(models.Model):
	username = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	height = models.IntegerField()
	weight = models.IntegerField()
	age = models.IntegerField()
	userID = models.CharField(max_length =20)

class weight_goal(models.Model):
	w_goal = models.TextField()

class sleep_goal(models.Model):
	s_goal = models.TextField()

class Health_Info(models.Model):
	BMI = models.IntegerField()
	occupation = models.TextField()
	avg_sleep = models.IntegerField()
	exercise_level = models.TextField()
	current_diet = models.TextField()

class exercise_goal(models.Model):
	e_goal = models.TextField()




