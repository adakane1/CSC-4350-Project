from django.contrib import admin

from .models import Users
admin.site.register(Users)

from .models import Health_Info
admin.site.register(Health_Info)

from .models import weight_goal
admin.site.register(weight_goal)

from .models import exercise_goal
admin.site.register(exercise_goal)

from .models import sleep_goal
admin.site.register(sleep_goal)