from django.apps import AppConfig


class SleepGoalConfig(AppConfig):
    name = 'sleep_goal'
