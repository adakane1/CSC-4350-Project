from django.apps import AppConfig


class ExerciseGoalConfig(AppConfig):
    name = 'exercise_goal'
