from django.apps import AppConfig


class HealthInfoConfig(AppConfig):
    name = 'Health_Info'
